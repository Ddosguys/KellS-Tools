# Darkness-tools

![Darkness-tools](https://github.com/Ddosguys/Darkness-tools/blob/main/Screenshot_20240729-185619.png)

## Introduction

Darkness-tools est une suite d'outils puissants conçus à des fins éducatives et d'apprentissage de la cybersécurité. Ce projet vise à fournir des ressources utiles pour ceux qui souhaitent approfondir leurs connaissances en sécurité informatique.

## Installation

Pour installer Darkness-tools, suivez les étapes ci-dessous :

```bash
git clone https://github.com/Ddosguys/Darkness-tools
cd Darkness-tools
python3 Setup.py
```
## Option : 
[Menu n°1]
```bash
[1] Tool Info
[2] Tool Website
[3] More Tool
[4] Backdoor Create
[5] Sql Injection
[6] Phishing URL
[7] Website Info Scanner
[8] Website Link Scanner
[9] Dox In Discord
[10] Search In DataBase
[11] Dox Create
[12] Dox Searcher
[13] Username Osint
[14] Email Searcher
[15] Email Osint
[16] Number Information
[17] Ip Info (Lookup)
[18] Ip Port Scanner
[19] DDoS IP
[20] Generate IP
[21] Password Encrypted
[22] Password Decrypted
[23] Your IP
[24] Token Information
[25] Token Nuker
[26] Token Joiner
[27] Token Leaver
[28] Webhook Spammer
[29] Token to Id
[30] More Page >
```

## Utilisation
Une fois l'installation terminée, vous pouvez commencer à utiliser Darkness-tools pour vos projets éducatifs et de recherche. Assurez-vous de bien comprendre les implications légales et éthiques de l'utilisation de ces outils.

## Avertissement
Attention: Cet outil est destiné à des fins éducatives uniquement. Toute utilisation abusive de Darkness-tools pour des activités illégales est strictement interdite. Utilisez cet outil de manière responsable et éthique.

## Auteur
Darkness-tools a été développé par KellS et lolo34dr.
